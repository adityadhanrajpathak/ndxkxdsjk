#arithmatice opraters
a = 12
b =13
print(a+b)
print(a-b)
print(a/b)
print(a*b) 
print(a**b)
print(12+4/2)
# assingnment operater
n =1222
#compound assingment opraters
# +=, -= *=/=
a = a+20
print(a)
#comparrision operater it provide  answer in true and flase 
# > < >= <= ==  !=
a = 12 
b = 12 
print(a==b)
print(a!=b)
print(ord("a"))
