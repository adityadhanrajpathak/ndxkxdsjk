age = int(input("hello what is you age "))
print(age)