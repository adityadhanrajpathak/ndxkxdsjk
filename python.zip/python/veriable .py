 # variable is use to  store the data 
shar ="aditya " 
print(shar)
# rule for variable is  number are not use at starts, space are not use in variable you should not use spical character in variable like @<#<$                
# camelcase - all small , pascal case - starting character of both capital , snake case - use _ between the words
AdityaDhanraj = "students " #P
adityaDhanraj ="students"#camel
Aditya_dhanraj 

