A = 12 #integer
print(type(A))
B = 12.940 #float
print(type(B))
V = 34j # complex
print(type(V))
#string
st = "e uqhuihe23iqwuqu9wwjijnkqds"
print(type(st))
#boolen
b = True
print(type(b))
n = "sher coder"
print(n[0:4:1])
# type conversion  

a = 12
a = str(a)
print(type(a))
#implicit mean it automatically convert the python one data type to another data type 

#explicit  mean it use build in function  like int() to convert the data type 
name = "akarsh"
age = "23"
print("hello my name is " ,name,"and my aye ",age)# not formeted string
                 
