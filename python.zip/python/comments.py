#hello for single line
"""hello this is me
"""

"""in python multiple line comment is posisble in the form of docs string 
"""